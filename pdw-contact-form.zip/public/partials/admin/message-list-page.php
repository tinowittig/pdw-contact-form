<?php foreach ( $messages as $message ) : ?>
    Message: <?php var_dump( $message->name ) ?>
<?php endforeach; ?>